#include "socketclient.h"

socketclient::socketclient()
{

}
