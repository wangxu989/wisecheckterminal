#ifndef PORT_H
#define PORT_H
#include<SerialPort.h>

class port
{
public:
    port();
};

#endif // PORT_H
