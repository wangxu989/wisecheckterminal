#ifndef QRENCODE_H
#define QRENCODE_H
#endif // QRENCODE_H
