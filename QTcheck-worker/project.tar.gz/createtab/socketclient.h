#ifndef SOCKETCLIENT_H
#define SOCKETCLIENT_H


class socketclient
{
public:
    socketclient();
};

#endif // SOCKETCLIENT_H