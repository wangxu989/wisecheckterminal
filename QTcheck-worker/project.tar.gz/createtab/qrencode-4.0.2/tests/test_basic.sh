#!/bin/sh -e
./test_bitstream
./test_estimatebit
./test_qrencode
./test_qrinput
./test_qrspec
./test_rs
./test_split
./test_mask
./test_mqrspec
./test_mmask
./test_monkey
