#ifndef MY_TABLEWIDGET_H
#define MY_TABLEWIDGET_H


class my_tablewidget
{
public:
    my_tablewidget();
};

#endif // MY_TABLEWIDGET_H